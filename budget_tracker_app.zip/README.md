# Budget Tracker App

A simple Django web application to track income and expenses.

## Features
- Add income and expenses
- View total balance
- Real-time summary calculations

## Tech Stack
- Python, Django
- SQLite/MySQL
- NumPy

## Usage
1. Clone the repo
2. Install requirements
3. Run migrations
4. Start server
