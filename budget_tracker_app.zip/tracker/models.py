from django.db import models

class Transaction(models.Model):
    TRANSACTION_TYPE = (
        ('Income', 'Income'),
        ('Expense', 'Expense'),
    )
    title = models.CharField(max_length=100)
    amount = models.FloatField()
    type = models.CharField(max_length=7, choices=TRANSACTION_TYPE)
    date = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} - {self.amount}"
