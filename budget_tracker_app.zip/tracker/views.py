from django.shortcuts import render, redirect
from .models import Transaction

def home(request):
    if request.method == 'POST':
        title = request.POST['title']
        amount = float(request.POST['amount'])
        t_type = request.POST['type']
        Transaction.objects.create(title=title, amount=amount, type=t_type)
        return redirect('home')

    transactions = Transaction.objects.all()
    income = sum(t.amount for t in transactions if t.type == 'Income')
    expense = sum(t.amount for t in transactions if t.type == 'Expense')
    balance = income - expense

    return render(request, 'tracker/home.html', {
        'transactions': transactions,
        'income': income,
        'expense': expense,
        'balance': balance
    })
